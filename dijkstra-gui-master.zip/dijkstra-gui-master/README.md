# dijkstra-gui
A java GUI program to demonstrate Dijkstra Algorithm to find shortest path between two points

### Working
- Allows to create node
- Drag node to node to create edge
- Set weight to edges
- Hold key and click node/edge to delete it
- Set source and destination node

### Screenshot
![](https://s24.postimg.org/wcvaayzdx/dj2.png)
